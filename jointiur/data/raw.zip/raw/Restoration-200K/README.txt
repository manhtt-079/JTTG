[Introduction]
The Restoration-200K dataset has about 200K multi-turn conversations in open-domain, and each of the conversations contains six utterances. The dataset is annotated and released by Tencent AI Lab. An annotation team is hired to (1) label whether an utterance is related to its context or not, and (2) restore an incomplete utterance to a complete and context-free form based on its context. Please refer to the paper "Improving Open-Domain Dialogue Systems via Multi-Turn Incomplete Utterance Restoration" in EMNLP 2019 for more details.


[Original Data Format]
Original dataset is saved in three .txt files. Each line is one conversation instance with the following format:

utte_1	utte_2	utte_3	utte_4	utte_5	utte_6	label(0/1)	restored_utterance(optional)

Each conversation consists of 6 utterances. The first 4 utterances are the context, where the restored words come from. The 5th utterance is the one to be restored. The 6th utterance is provided for reference only. "Label" indicates if the 5th utterance should be restored or not. If the label is 1, there will be one extra utterance at the end of the line, which is the restored utterance. Utterances and the label are separated with a "\t" token.


[Processed Data Format]
In the "processed data" folder, there is processed data for reproducing the proposed pick-and-combine method. "*.sr" files consist of input sequences and ".tr" files consist of target sequences. Each line is also one conversation. "*.sr" files follow the format below:

utte_1 <split> utte_2 <split> utte_3 <split> utte_4 || utte_5 | restored_words

Each conversation consists of 5 utterances. The first 4 utterances are the context, and they are separated by "<split>" token. The 5th is the original utterance to be restored, which is separated with the context with "||" token. Words after "|" token is the restored words, which are picked by sequences tagging model. In each utterance, characters are separated with a whitespace token " ". 

Note that restored words are defined as those words that do not appear the original utterance but are included in the context. In train/validation set, the restored words are extracted directly from the ground truth utterances. In test set, the restored words are extracted by a sequence tagging model.


[Citation]
Please cite our paper if you find this dataset useful:

@inproceedings{pan2019improving,
  title={Improving Open-Domain Dialogue Systems via Multi-Turn Incomplete Utterance Restoration},
  author={Zhufeng Pan, Kun Bai, Yan Wang, Lianqiang Zhou, and Xiaojiang Liu},
  booktitle={Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing},
  year={2019}
}


[License]
The dataset is released for academic research only. Any commercial usage please contact brandenwang@tencent.com for further authorization.